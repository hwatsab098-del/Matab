# مطب — Matab Android MVP

هذه نسخة Android Native أولية قابلة للبناء والتثبيت، هدفها إثبات تدفق المشروع كاملًا قبل إضافة نموذج YOLO الحقيقي والخادم المركزي.

## ما يعمل حاليًا

- واجهة عربية RTL.
- وضع قيادة مع Camera Preview باستخدام Camera2.
- GPS وتحديث الموقع والسرعة واتجاه الحركة عند توفره.
- تخزين المخاطر محليًا على الهاتف.
- الأنواع: حفرة، مطب، بلاعة مفتوحة، تلف طريق.
- Deduplication للمخاطر من نفس النوع داخل 12 مترًا.
- تنبيه صوتي عربي قبل الخطر إذا كان داخل 105 متر تقريبًا وفي اتجاه الحركة.
- تحديد تقريبي يمين/يسار حسب Bearing.
- Alert cooldown لمنع تكرار التنبيه لنفس الخطر لمدة 30 ثانية.
- Simulation Mode لاختبار التنبيهات بدون قيادة.
- نظام نقاط محلي بسيط.
- خريطة محلية Custom View للمخاطر القريبة بدون Google Maps API key.
- Detector Interface + MockDetector جاهزان لاستبدال الـMock بنموذج YOLO فعلي.

## مهم جدًا بخصوص الذكاء الاصطناعي

النسخة الحالية **لا تحتوي نموذج YOLO حقيقي** لأن ملف الأوزان Dataset/weights لم يتم توفيره بعد. `MockDetector` يولّد detections تجريبية للتأكد من أن دورة النظام كاملة تعمل: اكتشاف -> تخزين -> خريطة -> تنبيه.

عند توفر النموذج الحقيقي، يتم إنشاء implementation جديد لـ `Detector` وربطه في `DrivingActivity` بدل `MockDetector`.

## بناء APK على GitHub Actions

المشروع يحتوي workflow جاهز في `.github/workflows/build-apk.yml`.

بعد رفع المشروع إلى GitHub وتشغيل workflow `Build Matab APK` سيتم إنتاج:

`app/build/outputs/apk/debug/app-debug.apk`

ويتم رفعه كـ Artifact باسم `Matab-debug-apk`.

## بناء محلي

المتطلبات:

- JDK 17
- Android SDK Platform 35
- Android Build Tools
- Gradle 8.9

ثم من جذر المشروع:

```bash
gradle :app:assembleDebug
```

## الخطوة التالية للمشروع الكامل

1. ربط YOLO/ONNX/TFLite حقيقي بدل MockDetector.
2. إضافة Backend FastAPI + PostgreSQL/PostGIS.
3. مزامنة detections مع السيرفر وOffline Queue.
4. Google Maps أو OpenStreetMap حقيقية بدل الخريطة المحلية.
5. Admin Dashboard والتحقق من البلاغات.
6. Blur للوجوه ولوحات السيارات قبل رفع أي صورة للسيرفر.
