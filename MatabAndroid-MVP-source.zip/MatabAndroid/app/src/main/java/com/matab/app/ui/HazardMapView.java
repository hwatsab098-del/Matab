package com.matab.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.matab.app.data.Hazard;

import java.util.ArrayList;
import java.util.List;

public class HazardMapView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Hazard> hazards = new ArrayList<>();
    private double centerLat;
    private double centerLon;
    private boolean hasCenter;

    public HazardMapView(Context context) {
        super(context);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    public void setData(List<Hazard> hazards, double lat, double lon, boolean hasCenter) {
        this.hazards = hazards == null ? new ArrayList<>() : new ArrayList<>(hazards);
        this.centerLat = lat;
        this.centerLon = lon;
        this.hasCenter = hasCenter;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.rgb(14, 24, 32));
        int w = getWidth();
        int h = getHeight();

        paint.setStrokeWidth(Ui.dp(getContext(), 2));
        paint.setColor(Color.rgb(40, 60, 75));
        for (int x = 0; x < w; x += Ui.dp(getContext(), 52)) canvas.drawLine(x, 0, x, h, paint);
        for (int y = 0; y < h; y += Ui.dp(getContext(), 52)) canvas.drawLine(0, y, w, y, paint);

        float cx = w / 2f;
        float cy = h / 2f;
        paint.setColor(Color.rgb(47, 191, 113));
        canvas.drawCircle(cx, cy, Ui.dp(getContext(), 10), paint);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawCircle(cx, cy, Ui.dp(getContext(), 18), paint);
        paint.setStyle(Paint.Style.FILL);

        if (!hasCenter) {
            paint.setColor(Color.WHITE);
            paint.setTextSize(Ui.dp(getContext(), 16));
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("فعّل الموقع لعرض المخاطر حولك", cx, cy + Ui.dp(getContext(), 50), paint);
            return;
        }

        final double metersAcross = 600.0;
        for (Hazard hz : hazards) {
            double north = (hz.latitude - centerLat) * 111320.0;
            double east = (hz.longitude - centerLon) * 111320.0 * Math.cos(Math.toRadians(centerLat));
            float px = (float) (cx + east / metersAcross * w);
            float py = (float) (cy - north / metersAcross * h);
            if (px < 0 || px > w || py < 0 || py > h) continue;

            switch (hz.type) {
                case OPEN_MANHOLE: paint.setColor(Color.rgb(229,75,75)); break;
                case POTHOLE: paint.setColor(Color.rgb(245,183,0)); break;
                case SPEED_BUMP: paint.setColor(Color.rgb(64,145,230)); break;
                default: paint.setColor(Color.rgb(196,108,218)); break;
            }
            canvas.drawCircle(px, py, Ui.dp(getContext(), 10), paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(Ui.dp(getContext(), 11));
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(hz.type.arabic, px, py - Ui.dp(getContext(), 14), paint);
        }

        paint.setColor(Color.rgb(159,176,191));
        paint.setTextSize(Ui.dp(getContext(), 11));
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("خريطة محلية ~ 600m", Ui.dp(getContext(), 12), h - Ui.dp(getContext(), 14), paint);
    }
}
