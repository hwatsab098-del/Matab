package com.matab.app.ui;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.matab.app.data.Hazard;
import com.matab.app.data.HazardRepository;
import com.matab.app.detection.Detector;
import com.matab.app.detection.MockDetector;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DrivingActivity extends Activity implements LocationListener, TextToSpeech.OnInitListener {
    private static final int REQ_PERMS = 31;
    private TextureView preview;
    private TextView gpsText, aiText, hazardText, counterText, modeText;
    private HazardRepository repo;
    private Detector detector;
    private LocationManager locationManager;
    private Location lastLocation;
    private float heading;
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean tripRunning;
    private boolean simulation;
    private int detectedCount;
    private final Map<Long, Long> alertedAt = new HashMap<>();
    private final Handler uiHandler = new Handler();
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession cameraSession;

    private final Runnable simulationTick = new Runnable() {
        int step = 0;
        @Override public void run() {
            if (!simulation || !tripRunning) return;
            step++;
            // Synthetic northbound route. Seed hazards are relative to the start point.
            if (lastLocation != null) {
                Location synthetic = new Location("simulation");
                synthetic.setLatitude(lastLocation.getLatitude() + (step * 12.0) / 111320.0);
                synthetic.setLongitude(lastLocation.getLongitude());
                synthetic.setBearing(0f);
                synthetic.setSpeed(8f);
                evaluateWarnings(synthetic, 0f);
                modeText.setText("Simulation: " + (step * 12) + " متر");
            }
            uiHandler.postDelayed(this, 1100);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new HazardRepository(this);
        detector = new MockDetector();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        tts = new TextToSpeech(this, this);
        setContentView(buildUi());
        requestPermissionsIfNeeded();
    }

    private FrameLayout buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        Ui.hideSystemBars(root);

        preview = new TextureView(this);
        root.addView(preview, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(Ui.dp(this,16), Ui.dp(this,38), Ui.dp(this,16), Ui.dp(this,18));
        FrameLayout.LayoutParams overlayLp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(overlay, overlayLp);

        LinearLayout top = Ui.card(this);
        aiText = Ui.text(this, detector.status(), 14, Color.rgb(245,183,0), true);
        gpsText = Ui.text(this, "GPS: انتظار...", 14, Color.WHITE, false);
        counterText = Ui.text(this, "اكتشافات الرحلة: 0", 14, Color.WHITE, false);
        modeText = Ui.text(this, "الوضع: جاهز", 14, Color.rgb(159,176,191), false);
        top.addView(aiText); top.addView(gpsText); top.addView(counterText); top.addView(modeText);
        overlay.addView(top);

        hazardText = Ui.text(this, "", 28, Color.WHITE, true);
        hazardText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hazardLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        overlay.addView(hazardText, hazardLp);

        LinearLayout controls = Ui.card(this);
        android.widget.Button start = Ui.button(this, "ابدأ الرحلة", Color.rgb(47,191,113), Color.WHITE);
        start.setOnClickListener(v -> startTrip(false));
        controls.addView(start);
        android.widget.Button sim = Ui.button(this, "تشغيل Simulation Mode", Color.rgb(245,183,0), Color.rgb(16,24,32));
        sim.setOnClickListener(v -> startTrip(true));
        controls.addView(sim, Ui.margin(this, 8));
        android.widget.Button stop = Ui.button(this, "إيقاف الرحلة", Color.rgb(229,75,75), Color.WHITE);
        stop.setOnClickListener(v -> stopTrip());
        controls.addView(stop, Ui.margin(this, 8));
        android.widget.Button back = Ui.button(this, "رجوع", Color.rgb(35,50,62), Color.WHITE);
        back.setOnClickListener(v -> finish());
        controls.addView(back, Ui.margin(this, 8));
        overlay.addView(controls);

        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) { openCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
        });
        return root;
    }

    private void requestPermissionsIfNeeded() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERMS);
        } else startSensors();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) {
            startSensors();
            openCamera();
        }
    }

    private void startSensors() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsText.setText("GPS: بدون صلاحية");
            return;
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 700, 1f, this);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500, 2f, this);
        } catch (Exception e) {
            gpsText.setText("GPS: غير متاح");
        }
    }

    private void startTrip(boolean sim) {
        if (tripRunning) return;
        simulation = sim;
        tripRunning = true;
        detectedCount = 0;
        counterText.setText("اكتشافات الرحلة: 0");
        modeText.setText(sim ? "الوضع: Simulation" : "الوضع: قيادة فعلية");

        if (lastLocation != null) repo.ensureDemoHazards(lastLocation.getLatitude(), lastLocation.getLongitude());

        detector.start((type, confidence) -> {
            if (!tripRunning || simulation) return;
            if (lastLocation == null) {
                showHazard("تم رصد " + type.arabic + " — بانتظار GPS");
                return;
            }
            repo.addOrConfirm(type, lastLocation.getLatitude(), lastLocation.getLongitude(), confidence);
            detectedCount++;
            counterText.setText("اكتشافات الرحلة: " + detectedCount);
            showHazard("رصد: " + type.arabic + "  " + Math.round(confidence * 100) + "%");
        });

        if (sim) {
            if (lastLocation == null) {
                // Safe synthetic origin; does not represent the user's location.
                lastLocation = new Location("simulation-origin");
                lastLocation.setLatitude(30.0);
                lastLocation.setLongitude(31.0);
            }
            repo.ensureDemoHazards(lastLocation.getLatitude(), lastLocation.getLongitude());
            uiHandler.removeCallbacks(simulationTick);
            uiHandler.post(simulationTick);
        }
        speak("بدأت الرحلة");
    }

    private void stopTrip() {
        tripRunning = false;
        simulation = false;
        detector.stop();
        uiHandler.removeCallbacks(simulationTick);
        modeText.setText("الوضع: متوقف");
        hazardText.setText("");
        speak("تم إيقاف الرحلة");
    }

    @Override public void onLocationChanged(Location location) {
        lastLocation = location;
        if (location.hasBearing()) heading = location.getBearing();
        gpsText.setText(String.format(Locale.US, "GPS: %.5f, %.5f | %.0f km/h", location.getLatitude(), location.getLongitude(), location.getSpeed() * 3.6f));
        if (tripRunning && !simulation) evaluateWarnings(location, heading);
    }

    private void evaluateWarnings(Location loc, float currentHeading) {
        List<Hazard> nearby = repo.nearest(loc.getLatitude(), loc.getLongitude(), 120);
        long now = System.currentTimeMillis();
        for (Hazard h : nearby) {
            double distance = HazardRepository.distanceMeters(loc.getLatitude(), loc.getLongitude(), h.latitude, h.longitude);
            if (distance < 8 || distance > 105) continue;
            float bearing = HazardRepository.bearing(loc.getLatitude(), loc.getLongitude(), h.latitude, h.longitude);
            float diff = normalizeAngle(bearing - currentHeading);
            if (Math.abs(diff) > 65) continue;
            Long lastAlert = alertedAt.get(h.id);
            if (lastAlert != null && now - lastAlert < 30000) continue;
            alertedAt.put(h.id, now);
            String side = diff > 18 ? " ناحية اليمين" : diff < -18 ? " ناحية الشمال" : " قدامك";
            String msg = "خد بالك، " + h.type.arabic + side + " بعد " + Math.round(distance) + " متر";
            showHazard(msg);
            speak(msg);
            break;
        }
    }

    private float normalizeAngle(float angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    private void showHazard(String text) {
        hazardText.setText(text);
        uiHandler.postDelayed(() -> {
            if (hazardText.getText().toString().equals(text)) hazardText.setText("");
        }, 3500);
    }

    private void speak(String msg) {
        if (ttsReady) tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "matab-alert");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("ar", "EG"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
        }
    }

    private void openCamera() {
        if (!preview.isAvailable()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            cameraThread = new HandlerThread("matab-camera");
            cameraThread.start();
            cameraHandler = new Handler(cameraThread.getLooper());
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String selected = null;
            for (String id : manager.getCameraIdList()) {
                Integer facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { selected = id; break; }
            }
            if (selected == null && manager.getCameraIdList().length > 0) selected = manager.getCameraIdList()[0];
            if (selected == null) return;
            manager.openCamera(selected, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice cameraDevice) {
                    camera = cameraDevice;
                    createPreviewSession();
                }
                @Override public void onDisconnected(CameraDevice cameraDevice) { cameraDevice.close(); camera = null; }
                @Override public void onError(CameraDevice cameraDevice, int error) { cameraDevice.close(); camera = null; }
            }, cameraHandler);
        } catch (Exception e) {
            Toast.makeText(this, "الكاميرا غير متاحة: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void createPreviewSession() {
        try {
            SurfaceTexture texture = preview.getSurfaceTexture();
            if (texture == null || camera == null) return;
            texture.setDefaultBufferSize(1280, 720);
            Surface surface = new Surface(texture);
            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(surface);
            camera.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    cameraSession = session;
                    try {
                        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                        session.setRepeatingRequest(builder.build(), null, cameraHandler);
                    } catch (Exception ignored) {}
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {}
            }, cameraHandler);
        } catch (Exception ignored) {}
    }

    private void closeCamera() {
        try { if (cameraSession != null) cameraSession.close(); } catch (Exception ignored) {}
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        cameraSession = null; camera = null;
        if (cameraThread != null) { cameraThread.quitSafely(); cameraThread = null; cameraHandler = null; }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        stopTrip();
        closeCamera();
        try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        if (tts != null) { tts.stop(); tts.shutdown(); }
    }
}
