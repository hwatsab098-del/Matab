package com.matab.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class HazardRepository {
    private static final String PREFS = "matab_repo";
    private static final String KEY_HAZARDS = "hazards";
    private static final String KEY_POINTS = "points";
    private static final double DEDUPE_METERS = 12.0;

    private final Context context;
    private final AtomicLong ids = new AtomicLong(System.currentTimeMillis());
    private final List<Hazard> hazards = new ArrayList<>();

    public HazardRepository(Context context) {
        this.context = context.getApplicationContext();
        load();
    }

    public synchronized List<Hazard> all() {
        return new ArrayList<>(hazards);
    }

    public synchronized int getPoints() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_POINTS, 0);
    }

    public synchronized Hazard addOrConfirm(Hazard.Type type, double lat, double lon, float confidence) {
        for (Hazard h : hazards) {
            if (h.type == type && distanceMeters(lat, lon, h.latitude, h.longitude) <= DEDUPE_METERS) {
                h.confirmations += 1;
                addPoints(2);
                save();
                return h;
            }
        }
        Hazard h = new Hazard(ids.incrementAndGet(), type, lat, lon, confidence,
                System.currentTimeMillis(), 1);
        hazards.add(h);
        addPoints(10);
        save();
        return h;
    }

    public synchronized List<Hazard> nearest(double lat, double lon, double radiusMeters) {
        List<Hazard> out = new ArrayList<>();
        for (Hazard h : hazards) {
            if (distanceMeters(lat, lon, h.latitude, h.longitude) <= radiusMeters) out.add(h);
        }
        Collections.sort(out, Comparator.comparingDouble(h -> distanceMeters(lat, lon, h.latitude, h.longitude)));
        return out;
    }

    public synchronized void ensureDemoHazards(double lat, double lon) {
        if (!hazards.isEmpty()) return;
        addOrConfirm(Hazard.Type.POTHOLE, offsetLat(lat, 75), offsetLon(lat, lon, 15), 0.91f);
        addOrConfirm(Hazard.Type.OPEN_MANHOLE, offsetLat(lat, 145), offsetLon(lat, lon, -18), 0.88f);
        addOrConfirm(Hazard.Type.SPEED_BUMP, offsetLat(lat, 235), offsetLon(lat, lon, 8), 0.94f);
        addOrConfirm(Hazard.Type.ROAD_DAMAGE, offsetLat(lat, 340), offsetLon(lat, lon, -22), 0.83f);
    }

    private void addPoints(int delta) {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_POINTS, sp.getInt(KEY_POINTS, 0) + delta).apply();
    }

    private void load() {
        hazards.clear();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_HAZARDS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                hazards.add(new Hazard(
                        o.getLong("id"),
                        Hazard.Type.valueOf(o.getString("type")),
                        o.getDouble("lat"),
                        o.getDouble("lon"),
                        (float) o.getDouble("confidence"),
                        o.getLong("createdAt"),
                        o.optInt("confirmations", 1)
                ));
            }
        } catch (Exception ignored) { }
    }

    private void save() {
        JSONArray arr = new JSONArray();
        try {
            for (Hazard h : hazards) {
                JSONObject o = new JSONObject();
                o.put("id", h.id);
                o.put("type", h.type.name());
                o.put("lat", h.latitude);
                o.put("lon", h.longitude);
                o.put("confidence", h.confidence);
                o.put("createdAt", h.createdAt);
                o.put("confirmations", h.confirmations);
                arr.put(o);
            }
        } catch (Exception ignored) { }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_HAZARDS, arr.toString()).apply();
    }

    public static double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371000.0;
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1);
        double dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static float bearing(double lat1, double lon1, double lat2, double lon2) {
        double y = Math.sin(Math.toRadians(lon2 - lon1)) * Math.cos(Math.toRadians(lat2));
        double x = Math.cos(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2))
                - Math.sin(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.cos(Math.toRadians(lon2 - lon1));
        return (float) ((Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0);
    }

    private static double offsetLat(double lat, double northMeters) {
        return lat + northMeters / 111320.0;
    }

    private static double offsetLon(double lat, double lon, double eastMeters) {
        double metersPerDegree = 111320.0 * Math.cos(Math.toRadians(lat));
        if (Math.abs(metersPerDegree) < 1) metersPerDegree = 1;
        return lon + eastMeters / metersPerDegree;
    }
}
