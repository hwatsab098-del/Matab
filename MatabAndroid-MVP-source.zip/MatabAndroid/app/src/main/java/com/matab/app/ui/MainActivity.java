package com.matab.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.matab.app.data.HazardRepository;

public class MainActivity extends Activity {
    private TextView stats;
    private HazardRepository repo;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new HazardRepository(this);
        setContentView(buildUi());
    }

    @Override protected void onResume() {
        super.onResume();
        if (stats != null) stats.setText("المخاطر المسجلة: " + repo.all().size() + "     نقاطك: " + repo.getPoints());
    }

    private ScrollView buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 24, 32));
        Ui.hideSystemBars(scroll);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.RIGHT);
        root.setPadding(Ui.dp(this, 22), Ui.dp(this, 52), Ui.dp(this, 22), Ui.dp(this, 24));
        scroll.addView(root);

        TextView logo = Ui.text(this, "مطب", 40, Color.rgb(245, 183, 0), true);
        logo.setTextDirection(TextView.TEXT_DIRECTION_RTL);
        root.addView(logo);

        TextView subtitle = Ui.text(this, "Matab — عين الطريق الذكية", 20, Color.WHITE, true);
        root.addView(subtitle);
        TextView desc = Ui.text(this,
                "نسخة MVP لتسجيل مخاطر الطريق والتنبيه منها أثناء القيادة. التحليل الحالي تجريبي Mock AI لحين إضافة نموذج YOLO الحقيقي.",
                15, Color.rgb(159,176,191), false);
        desc.setTextDirection(TextView.TEXT_DIRECTION_RTL);
        root.addView(desc, Ui.margin(this, 10));

        stats = Ui.text(this, "", 17, Color.WHITE, true);
        LinearLayout statCard = Ui.card(this);
        statCard.addView(stats);
        root.addView(statCard, Ui.margin(this, 22));

        android.widget.Button drive = Ui.button(this, "ابدأ وضع القيادة", Color.rgb(245,183,0), Color.rgb(16,24,32));
        drive.setOnClickListener(v -> startActivity(new Intent(this, DrivingActivity.class)));
        root.addView(drive, Ui.margin(this, 18));

        android.widget.Button map = Ui.button(this, "خريطة المخاطر", Color.rgb(47,191,113), Color.WHITE);
        map.setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class)));
        root.addView(map, Ui.margin(this, 12));

        LinearLayout features = Ui.card(this);
        features.addView(Ui.text(this, "الموجود في النسخة دي", 19, Color.WHITE, true));
        features.addView(Ui.text(this,
                "كاميرا مباشرة أثناء القيادة\nGPS وموقع واتجاه الحركة\nتسجيل حفرة / مطب / بلاعة / تلف طريق\nمنع تكرار البلاغات القريبة\nتنبيهات صوتية بالعربي\nSimulation Mode\nنقاط للسائق\nخريطة محلية للمخاطر\nواجهة Detector جاهزة لربط YOLO",
                15, Color.rgb(220,229,236), false));
        root.addView(features, Ui.margin(this, 22));

        TextView warning = Ui.text(this,
                "تنبيه: استخدم الهاتف مثبتًا في حامل ولا تتفاعل مع الشاشة أثناء القيادة.",
                14, Color.rgb(229,75,75), true);
        root.addView(warning, Ui.margin(this, 18));
        return scroll;
    }
}
