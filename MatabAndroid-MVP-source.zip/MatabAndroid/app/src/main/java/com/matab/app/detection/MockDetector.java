package com.matab.app.detection;

import android.os.Handler;
import android.os.Looper;

import com.matab.app.data.Hazard;

import java.util.Random;

public class MockDetector implements Detector {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private boolean running;
    private Listener listener;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            // Demo only: occasional synthetic detection to validate the full pipeline.
            if (random.nextFloat() > 0.58f && listener != null) {
                Hazard.Type[] values = Hazard.Type.values();
                Hazard.Type type = values[random.nextInt(values.length)];
                float confidence = 0.78f + random.nextFloat() * 0.20f;
                listener.onDetection(type, confidence);
            }
            handler.postDelayed(this, 7000);
        }
    };

    @Override public void start(Listener listener) {
        this.listener = listener;
        running = true;
        handler.postDelayed(tick, 3500);
    }

    @Override public void stop() {
        running = false;
        handler.removeCallbacks(tick);
    }

    @Override public String status() {
        return "Mock AI — جاهز للاستبدال بـ YOLO";
    }
}
