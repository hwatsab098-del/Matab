package com.matab.app.detection;

import com.matab.app.data.Hazard;

public interface Detector {
    interface Listener {
        void onDetection(Hazard.Type type, float confidence);
    }
    void start(Listener listener);
    void stop();
    String status();
}
