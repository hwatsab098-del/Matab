package com.matab.app.ui;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.matab.app.data.HazardRepository;

public class MapActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 20;
    private HazardRepository repo;
    private HazardMapView mapView;
    private TextView status;
    private LocationManager lm;
    private Location last;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new HazardRepository(this);
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        setContentView(buildUi());
        requestLocation();
    }

    private LinearLayout buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16,24,32));
        root.setPadding(Ui.dp(this,16), Ui.dp(this,45), Ui.dp(this,16), Ui.dp(this,18));
        Ui.hideSystemBars(root);

        TextView title = Ui.text(this, "خريطة المخاطر", 26, Color.WHITE, true);
        title.setGravity(Gravity.RIGHT);
        root.addView(title);
        status = Ui.text(this, "جاري تحديد موقعك...", 14, Color.rgb(159,176,191), false);
        root.addView(status);

        mapView = new HazardMapView(this);
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        mapLp.topMargin = Ui.dp(this, 14);
        root.addView(mapView, mapLp);

        android.widget.Button seed = Ui.button(this, "أضف مخاطر تجريبية حول موقعي", Color.rgb(245,183,0), Color.rgb(16,24,32));
        seed.setOnClickListener(v -> {
            if (last != null) {
                repo.ensureDemoHazards(last.getLatitude(), last.getLongitude());
                refresh();
            } else {
                status.setText("الموقع غير متاح بعد");
            }
        });
        root.addView(seed, Ui.margin(this, 12));

        android.widget.Button back = Ui.button(this, "رجوع", Color.rgb(35,50,62), Color.WHITE);
        back.setOnClickListener(v -> finish());
        root.addView(back, Ui.margin(this, 10));
        return root;
    }

    private void requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1f, this);
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 2f, this);
        } catch (Exception e) {
            status.setText("تعذر تشغيل الموقع: " + e.getMessage());
        }
    }

    private void refresh() {
        if (last == null) mapView.setData(repo.all(), 0, 0, false);
        else {
            mapView.setData(repo.nearest(last.getLatitude(), last.getLongitude(), 1000),
                    last.getLatitude(), last.getLongitude(), true);
            status.setText("مخاطر قريبة: " + repo.nearest(last.getLatitude(), last.getLongitude(), 1000).size());
        }
    }

    @Override public void onLocationChanged(Location location) {
        last = location;
        refresh();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestLocation();
        else status.setText("صلاحية الموقع مطلوبة للخريطة الحية");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { lm.removeUpdates(this); } catch (Exception ignored) {}
    }
}
