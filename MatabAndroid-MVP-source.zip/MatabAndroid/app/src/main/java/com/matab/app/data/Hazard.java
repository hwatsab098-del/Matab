package com.matab.app.data;

public class Hazard {
    public enum Type {
        POTHOLE("حفرة"),
        SPEED_BUMP("مطب"),
        OPEN_MANHOLE("بلاعة مفتوحة"),
        ROAD_DAMAGE("تلف طريق");

        public final String arabic;
        Type(String arabic) { this.arabic = arabic; }
    }

    public final long id;
    public final Type type;
    public final double latitude;
    public final double longitude;
    public final float confidence;
    public final long createdAt;
    public int confirmations;

    public Hazard(long id, Type type, double latitude, double longitude,
                  float confidence, long createdAt, int confirmations) {
        this.id = id;
        this.type = type;
        this.latitude = latitude;
        this.longitude = longitude;
        this.confidence = confidence;
        this.createdAt = createdAt;
        this.confirmations = confirmations;
    }
}
