package com.matab.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static TextView text(Context c, String value, int sp, int color, boolean bold) {
        TextView tv = new TextView(c);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.RIGHT);
        if (bold) tv.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        tv.setPadding(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        return tv;
    }

    public static Button button(Context c, String label, int bgColor, int textColor) {
        Button b = new Button(c);
        b.setText(label);
        b.setTextSize(17);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, 16));
        b.setBackground(gd);
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(23, 35, 46));
        gd.setCornerRadius(dp(c, 18));
        card.setBackground(gd);
        return card;
    }

    public static LinearLayout.LayoutParams margin(Context c, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = dp(c, top);
        return lp;
    }

    public static void hideSystemBars(View root) {
        root.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }
}
